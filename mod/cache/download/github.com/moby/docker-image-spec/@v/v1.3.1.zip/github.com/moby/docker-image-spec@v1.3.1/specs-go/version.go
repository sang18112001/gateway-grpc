package specs

const (
	Version      = "v1.3"
	VersionMajor = 1
	VersionMinor = 3
)
