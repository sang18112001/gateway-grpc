package credentials

func defaultCredentialsStore() string {
	return "osxkeychain"
}
