// Package connections provides libraries to work with network connections.
// This library is divided in several components for specific usage.
package connections
