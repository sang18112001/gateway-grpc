bond doc
