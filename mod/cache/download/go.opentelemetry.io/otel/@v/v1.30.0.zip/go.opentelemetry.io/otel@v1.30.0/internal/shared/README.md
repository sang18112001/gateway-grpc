# Shared

Code under this directory contains reusable internal code which is distributed across packages using `//go:generate gotmpl` in `gen.go` files.
