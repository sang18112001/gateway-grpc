# Semconv v1.18.0 HTTP conv

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/semconv/v1.18.0/httpconv)](https://pkg.go.dev/go.opentelemetry.io/otel/semconv/v1.18.0/httpconv)
